const settings = {
  ownerName: 'NamaOwnerLu', // Ganti dengan nama owner lu
  botToken: '7944249117:AAEmxDYpMFvVuQ6AiTefYAIqyGE5LrhFiNE', // Ganti dengan token bot Telegram lu
  owner: '6361969853', //OWNER user id
};

module.exports = settings;
